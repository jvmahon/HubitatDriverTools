metadata {
	definition (name: "Test - Delete Attribute",namespace: "jvm", author: "jvm") {
		capability "Initialize"

		attribute "heartbeat", "string"
		
		command "writeData"
    }
}

void initialize() {
	device.deleteCurrentState("heartbeat") 
}	

void writeData() {
	if (device.hasAttribute("heartbeat")) { 
		log.debug "Device has the heartbeat attribute"
		device.sendEvent([name:"heartbeat", value:"This is a test"])
	} else {
		log.debug "Device does not have the heartbeat attribute"
	}
}

