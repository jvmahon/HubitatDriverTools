//////////////
#include zwaveTools.sendReceiveTools
Integer getS2MaxRetries() { return 5 }
/////////// 
#include zwaveTools.globalDataTools
#include zwaveTools.zwaveDeviceDatabase

#include zwaveTools.parameterGetSendTools

metadata {
	definition (name: "00 - Parameter Controls Tester",namespace: "jvm", author: "jvm", singleThreaded:false) {
		capability "Initialize"
		
		command "setParameter",[[name:"parameterNumber",type:"NUMBER", description:"Parameter Number", constraints:["NUMBER"]],
					[name:"value",type:"NUMBER", description:"Parameter Value", constraints:["NUMBER"]]
					]	
		
		command "getParameter",[[name:"parameterNumber",type:"NUMBER", description:"Parameter Number", constraints:["NUMBER"]]
					]		
		command "showParameterStorageMap"
		command "clearSettings"
    }
	
	preferences  {	
        input name: "showParameterInputs", type: "bool", title: "Show Parameter Value Input Controls", defaultValue: false    
		input name: "logEnable", type: "bool", title: "Enable debug logging", defaultValue: false
		input name: "txtEnable", type: "bool", title: "Enable text logging", defaultValue: true

		if (showParameterInputs) {
			// parameterStorageMap.each{k, v -> device.updateSetting("${k}", v as Integer)}
			getInputs().each{key, value -> input value}
        }
    }	
}

def updated(){
	// waiting for the Boolean prevents updated from returning prematurely
	Boolean done = updateDeviceSettings()
}

void initialize(){
	// log.info "All Parameter values are: " + getAllParameterValues()
}

void handleParameterReport(hubitat.zwave.commands.configurationv2.ConfigurationReport  cmd) {
	if (logEnable) log.debug "Function handleParameterReport received the report ${cmd}."
}
