
/////////////////


metadata {
	definition (name: "Simple Parse Test",namespace: "jvm", author: "jvm") {
		command "createChildren"
		command "deleteChildren"
        command "test1"
        command "test2"
		command "test3"
		command "test4"
				command "test5"
		command "test6"
				command "test7"
    }
}

void createChildren(){
	addChildDevice("hubitat", "Generic Component Switch", device.deviceNetworkId +".child1-ep000", [name:"child1", isComponent: false])
	addChildDevice("hubitat", "Generic Component Switch", device.deviceNetworkId +".child2-ep000", [name:"child2", isComponent: false])
	addChildDevice("hubitat", "Generic Component Switch", device.deviceNetworkId +".child3-ep000", [name:"child3", isComponent: false])
}

void deleteChildren()  {
	childDevices.each{ deleteChildDevice(it.deviceNetworkId) }
}


void componentRefresh(cd) {
}

void test1() {  
    log.debug this.class
	(childDevices + device).each{log.debug "Device has attribute switch: ${it.hasAttribute("switch")}"}
}

void test2() {    
	(childDevices + device).each{log.debug "Device ${it.displayName} has attribute switch: ${it.hasAttribute("switch")}"}
}

void test3() {    
	(childDevices + this).each{it.parse([[name:"switch", value:"on", descriptionTest:"Received event at device ${it.displayName}"]])}
}

void test4() {    
	// device.parse = this.&parse
	
	(childDevices + device).each{it.parse([[name:"switch", value:"on", descriptionTest:"Received event at device ${it.displayName}"]])}
}

void test5() {
log.debug device.properties.sort{it.key}.collect{it}.findAll{!['class', 'active'].contains(it.key)}.join('\n')
}
void test6() {
childDevices.each{ log.debug it.properties.sort{it.key}.collect{it}.findAll{!['class', 'active'].contains(it.key)}.join('\n') }
}
void test7() {
log.debug this.properties.sort{it.key}.collect{it}.join('\n')
}
void parse(List<Map> description) {
    description.each {
        if (it.name in ["switch","level"]) {
            log.info it.descriptionText
            sendEvent(it)
        }
    }
}